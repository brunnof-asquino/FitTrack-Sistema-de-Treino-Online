const User = require('./userModel');
const bcrypt = require('bcryptjs');
const { Op } = require('sequelize');
const fs = require('fs');
const path = require('path');
const Workout = require('../workout/workoutModel');  

async function registerUser(username, email, password, fullName) {
    const emailExists = await User.findOne({ where: { email } });
    const usernameExists = await User.findOne({ where: { username } });
    
    if (emailExists || usernameExists) {
        throw new Error('Este e-mail ou usuário já está cadastrado.');
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    const newUser = await User.create({
        username,
        email,
        password: hashedPassword,
        fullName
    });
    return {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email
    };
}

async function loginUser(login, password) {
    const user = await User.findOne({
        where: {
            [Op.or]: [{ email: login }, { username: login }]
        }
    });

    if (!user || !(await bcrypt.compare(password, user.password))) {
        throw new Error('E-mail/Usuário ou senha incorretos.');
    }

    return user;
}

async function getUserProfile(userId) {
    const user = await User.findByPk(userId, {
        attributes: ['id', 'username', 'email', 'fullName', 'bio', 'profilePicture', 'followersCount', 'followingCount', 'workoutsCount', 'isAdmin']
    });

    if (!user) {
        throw new Error('Usuário não encontrado.');
    }

    return user;
}

async function getPublicProfile(username) {
    const user = await User.findOne({
        where: { username },
        attributes: ['id', 'username', 'fullName', 'bio', 'profilePicture', 'followersCount', 'followingCount', 'workoutsCount'],
        include: [{                                                 
            model: Workout,
            attributes: ['id', 'title', 'thumbnailPath', 'views', 'likesCount', 'commentsCount']
        }],
        order: [[Workout, 'createdAt', 'DESC']]                      
    });

    if (!user) {
        const error = new Error('Usuário não encontrado.');
        error.status = 404;
        throw error;
    }

    return user;
}

async function updateUserProfile(userId, fullName, bio, newProfilePictureFilename) {
    const updateData = { fullName, bio };
    let oldProfilePicture = null;

    if (newProfilePictureFilename) {
        const oldUser = await User.findByPk(userId);
        if (oldUser && oldUser.profilePicture && oldUser.profilePicture !== 'default-profile.png') {
            oldProfilePicture = oldUser.profilePicture;
        }
        updateData.profilePicture = newProfilePictureFilename;
    }

    await User.update(updateData, { where: { id: userId } });

    if (oldProfilePicture) {
        const oldProfilePicPath = path.join(__dirname, '../../public/uploads/profiles', oldProfilePicture);
        fs.unlink(oldProfilePicPath, (err) => {
            if (err) console.error('Erro ao apagar foto de perfil antiga:', err);
            else console.log('Foto de perfil antiga apagada:', oldProfilePicPath);
        });
    }

    return getUserProfile(userId);
}

module.exports = { registerUser, loginUser, getUserProfile, getPublicProfile, updateUserProfile  };