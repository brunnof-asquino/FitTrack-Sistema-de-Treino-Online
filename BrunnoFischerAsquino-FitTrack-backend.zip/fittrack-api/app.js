var express = require('express');
var path = require('path');
var logger = require('morgan');
var cors = require('cors');
require('dotenv').config();

var indexRouter = require('./routes/index');
var searchRoutes = require('./modules/search/searchRoutes'); 
var userRoutes = require('./modules/user/userRoutes'); 
var workoutRoutes = require('./modules/workout/workoutRoutes')
var likeRoutes = require('./modules/like/likeRoutes');             
var commentRoutes = require('./modules/comment/commentRoutes'); 
var errorHandler = require('./middlewares/errorHandler');

var app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(cors({
    origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
    credentials: true
}));

app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));
app.use('/api', indexRouter);
app.use('/api', searchRoutes);
app.use('/api', userRoutes);  
app.use('/api', workoutRoutes);
app.use('/api', likeRoutes);                                        
app.use('/api', commentRoutes);   

app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Rota não encontrada.',
        erros: []
    });
});

app.use(errorHandler); 

require('./config/associations');
const sequelize = require('./config/database');
sequelize.sync({ alter: true })
    .then(() => console.log('Banco de dados sincronizado!'))
    .catch(err => console.error('Erro ao sincronizar banco:', err));

module.exports = app;